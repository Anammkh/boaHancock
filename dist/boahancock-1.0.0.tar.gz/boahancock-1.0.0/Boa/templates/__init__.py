"""
{project_name} module.
"""

